import itertools
import random

import pytest

from autotrade8.backtest import (
    Trade,
    estimate_move,
    evaluate,
    max_drawdown_bps,
    net_bps,
    parameter_stability,
    profit_factor,
    run_backtest,
    simulate_exit,
    to_eligibility,
)
from autotrade8.breakout import BreakoutConfig, ExecInfo
from autotrade8.lifecycle import paper_eligibility
from autotrade8.volume_zone import Bar

CFG = BreakoutConfig()


def bar(i, o, h, l, c, v=1000.0):
    return Bar(float(i), o, h, l, c, v)


def flat(n, px=100.0):
    return [bar(i, px, px + 0.5, px - 0.5, px) for i in range(n)]


def test_entry_is_next_open_not_signal_close():
    b = flat(5)
    b[1] = bar(1, 100, 100.5, 99.5, 100)
    b[2] = bar(2, 103.0, 103.2, 102.9, 103.0)  # gap open: entry price must be 103, not 100
    tr = simulate_exit("X", b, 1, 1.0, CFG, 3)
    assert tr.entry_idx == 2 and tr.entry_price == 103.0


def test_stop_runner_ambiguity_and_gap():
    # stop = 100-1.3 = 98.7 ; runner = 100+2.75 = 102.75 ; ATR = 1
    base = [bar(0, 100, 100.5, 99.5, 100), bar(1, 100, 100.2, 99.8, 100)]
    hit_stop = simulate_exit("X", base + [bar(2, 100, 100.2, 98.0, 98.5)], 0, 1.0, CFG, 5)
    assert hit_stop.exit_reason == "STOP" and hit_stop.exit_price == pytest.approx(98.7)
    both = simulate_exit("X", base + [bar(2, 100, 103.0, 98.0, 100)], 0, 1.0, CFG, 5)
    assert both.exit_reason == "STOP"  # same-bar ambiguity resolved against us
    gap = simulate_exit("X", base + [bar(2, 100, 100.2, 99.9, 100), bar(3, 97.0, 97.5, 96.5, 97)],
                        0, 1.0, CFG, 5)
    assert gap.exit_reason == "STOP" and gap.exit_price == 97.0  # gap through stop fills at open
    run = simulate_exit("X", base + [bar(2, 100, 103.0, 99.9, 102.9)], 0, 1.0, CFG, 5)
    assert run.exit_reason == "RUNNER" and run.gross_bps > 200


def test_time_stop_and_unresolved():
    b = [bar(0, 100, 100.5, 99.5, 100)] + [bar(i, 100, 100.4, 99.8, 100.1) for i in range(1, 10)]
    tr = simulate_exit("X", b, 0, 1.0, BreakoutConfig(time_stop_bars=3), 8)
    assert tr.exit_reason == "TIME_STOP" and tr.bars_held == 3
    assert simulate_exit("X", b[:3], 0, 1.0, CFG, 8) is None  # unresolved: dropped


def T(sym="A", sig=0, ent=1, ex=2, gross=100.0, held=3):
    return Trade(sym, sig, ent, ex, 100.0, 101.0, "RUNNER", gross, -10.0, 120.0, held)


def test_costs_and_metrics():
    info = ExecInfo("gate", "A", 2.0, 1.0, 2.0, funding_bps_per_hour=0.5)
    assert net_bps(T(), info) == pytest.approx(100 - 2 * 5 - 0.5 * 3)
    assert net_bps(T(), info, cost_mult=2.0, extra_bps=5.0) == pytest.approx(100 - 2 * 11.5 - 5)  # stress doubles ALL costs incl. funding
    assert profit_factor([10, -5, 5]) == 3.0 and profit_factor([1, 2]) == float("inf")
    assert max_drawdown_bps([10, -4, -3, 8, -9]) == 9.0
    assert estimate_move([]) is None
    m = estimate_move([T(gross=50), T(gross=-10), T(gross=30)])
    assert m.n == 3 and m.median_move_bps == 30 and m.evidence_score == pytest.approx(0.03 * 2 / 3)


def test_evaluate_segments_and_no_boundary_straddling():
    info = {"A": ExecInfo("gate", "A", 2.0, 1.0)}
    total = 1000
    good = [T(ent=100, ex=105), T(ent=530, ex=535), T(ent=730, ex=735), T(ent=880, ex=885)]
    straddle = T(ent=495, ex=505)  # crosses SELECTION/VALIDATION boundary -> excluded
    r = evaluate(good + [straddle], info, total, max_hold_bars=12, embargo=24)
    assert r.n == {"SELECTION": 1, "VALIDATION": 1, "TEST": 1, "HOLDOUT": 1}
    assert r.n_total == 4 and r.oos_net > 0 and r.stress_net > 0
    assert parameter_stability([r], min_n=4) and not parameter_stability([r], min_n=30)
    assert not parameter_stability([])


def test_never_eligible_on_backtest_alone():
    info = {"A": ExecInfo("gate", "A", 2.0, 1.0)}
    trades = [T(ent=100 + 10 * i, ex=102 + 10 * i) for i in range(20)]
    trades += [T(ent=530 + 10 * i, ex=532 + 10 * i) for i in range(10)]
    trades += [T(ent=730 + 10 * i, ex=732 + 10 * i) for i in range(10)]
    trades += [T(ent=880 + 10 * i, ex=882 + 10 * i) for i in range(10)]
    r = evaluate(trades, info, 1000, 12, 24)
    fails = paper_eligibility(to_eligibility(r, parameter_stable=True))
    assert "EXECUTION_MODEL_NOT_CREDIBLE" in fails  # needs PAPER calibration
    assert "CONCENTRATION_TOO_HIGH" in fails  # single-symbol


def market(seed, n=500, syms=("BTC", "A", "B", "C", "D", "E")):
    rnd = random.Random(seed)
    out = {}
    for s in syms:
        c, bars = 100.0, []
        for i in range(n):
            o = c
            c = c * (1 + rnd.gauss(0.0002, 0.006))
            h, l = max(o, c) * 1.002, min(o, c) * 0.998
            bars.append(bar(i, o, h, l, c, 1e5 * (3 if rnd.random() < 0.08 else 1)))
        out[s] = bars
    return out


def test_backtest_runs_one_position_at_a_time_and_is_honest_on_noise():
    u = market(11)
    execs = {s: ExecInfo("gate", s, 5.0, 2.0, 3.0) for s in u}
    cfg = BreakoutConfig(min_quote_volume_usd=1.0)
    trades = run_backtest(u, execs, "BTC", cfg)
    for a, b in itertools.pairwise(trades):
        assert b.signal_idx >= a.exit_idx  # no overlap
    assert all(t.entry_idx == t.signal_idx + 1 for t in trades)
    rep = evaluate(trades, execs, 500, 12, 24)
    # random walks + realistic costs must not look like alpha
    assert not (rep.n_total >= 30 and rep.oos_net > 0 and rep.net_all > 0)
    assert paper_eligibility(to_eligibility(r=rep, parameter_stable=False))
