from autotrade8.lifecycle import EligibilityMetrics, LifecycleRegistry
from autotrade8.opportunity import Lifecycle
from autotrade8.tournament import TournamentEntry, render


def test_tournament_never_fills_missing_evidence():
    reg = LifecycleRegistry()
    reg.register("REST_MOMENTUM_TOURNAMENT_V2", Lifecycle.RETIRED)
    reg.register("FUNDING_CARRY_V1")
    reg.register("CROSS_EXCHANGE_BASIS_V1")
    legacy = EligibilityMetrics(400, -3.0, -8.0, 0.7, -1, -1, -1, -2, 25.0, 40.0, False, True)
    txt = render(reg, [
        TournamentEntry("REST_MOMENTUM_TOURNAMENT_V2", legacy),
        TournamentEntry("FUNDING_CARRY_V1"),
        TournamentEntry("CROSS_EXCHANGE_BASIS_V1"),
    ])
    lines = txt.splitlines()
    assert "RETIRED" in lines[2] and "GROSS_EXPECTANCY_NOT_POSITIVE" in lines[2]
    assert lines[3].rstrip().endswith("INSUFFICIENT_EVIDENCE")
    assert lines[4].rstrip().endswith("INSUFFICIENT_EVIDENCE")
