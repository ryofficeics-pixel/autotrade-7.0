import random

import pytest

from autotrade8.basis import (
    BasisConfig,
    SpreadSeries,
    historical_convergence,
    mean_reversion_stats,
    rolling_z,
    scan_cross_exchange_basis,
)
from autotrade8.opportunity import Lifecycle, VenueHealth
from autotrade8.scanner import BookTop, OpportunityScanner, PerpSnapshot
from autotrade8.sentry import evaluate
from tests.helpers import make_ctx

NOW = 1000.0


def ou(n, phi=0.9, sigma=2.0, seed=1, x0=0.0):
    rnd, x, out = random.Random(seed), x0, []
    for _ in range(n):
        x = phi * x + rnd.gauss(0, sigma)
        out.append(x)
    return out


def snap(venue, mid, half=1.0, fee=0.5, size=50.0, ts=NOW):
    return PerpSnapshot(venue, "BTC-PERP", "BTC", ts, BookTop(mid - half, mid + half, size, size),
                        mid, mid, 0.0001, 8.0, NOW + 3600, (0.0001,) * 8, fee)


def pair(spread_bps):
    b_mid = 50_000.0
    a_mid = b_mid * (1 + spread_bps / 1e4)  # A rich when spread > 0
    return snap("gate", a_mid), snap("okx", b_mid)


def test_stats_stationary_vs_random_walk():
    s = mean_reversion_stats(ou(1500, phi=0.9))
    assert s.stationary and s.phi == pytest.approx(0.9, abs=0.05)
    assert s.half_life_steps == pytest.approx(6.6, abs=1.5)
    rw = mean_reversion_stats(ou(1500, phi=1.0, seed=0))
    assert not rw.stationary


def test_rolling_z_is_causal():
    x = ou(300)
    full = rolling_z(x, 200, 60)
    x2 = x[:201] + [1e6] * 99  # change the future
    assert rolling_z(x2, 200, 60) == full


def test_convergence_events_ou_vs_random_walk():
    good = historical_convergence(ou(2000), 60, 2.0, 0.5, 240)
    bad = historical_convergence(ou(2000, phi=1.0, seed=5), 60, 2.0, 0.5, 20)
    assert good.n_events >= 8 and good.converge_rate > 0.9 and good.mean_capture_bps > 0
    assert bad.converge_rate < good.converge_rate


def series(vals):
    return SpreadSeries(60.0, tuple(vals))


def test_scan_emits_opportunity_and_orientation():
    a, b = pair(60.0)
    r = scan_cross_exchange_basis(a, b, series(ou(1500)), 1000.0, NOW)
    assert r.reject_reason is None, r.details
    o = r.opportunity
    assert [(leg.venue, leg.side.value) for leg in o.legs] == [("gate", "SHORT"), ("okx", "LONG")]
    assert o.gross_expected_edge_bps == pytest.approx(60.0, rel=0.05)
    o.lifecycle = Lifecycle.PAPER_ACTIVE
    ctx = make_ctx(now=NOW, equity=5000.0, available_capital=5000.0,
                   venue_health={"gate": VenueHealth.HEALTHY, "okx": VenueHealth.HEALTHY})
    assert evaluate(o, ctx).state == "CLEARED"
    b2, a2 = pair(60.0)  # swap roles: orientation follows the sign, not argument order
    r2 = scan_cross_exchange_basis(b2, a2, series(ou(1500)), 1000.0, NOW)
    assert r2.opportunity.legs[0].venue == "gate"


def test_small_dislocation_is_blocked_by_costs():
    a, b = pair(14.0)
    o = scan_cross_exchange_basis(a, b, series(ou(1500)), 1000.0, NOW).opportunity
    o.lifecycle = Lifecycle.PAPER_ACTIVE
    r = evaluate(o, make_ctx(now=NOW, equity=5000.0, available_capital=5000.0))
    assert r.state == "BLOCKED"
    assert any("EDGE" in f or "COST" in f for f in r.all_failures)


@pytest.mark.parametrize("vals,spread,reasons", [
    (ou(100), 60.0, {"INSUFFICIENT_HISTORY"}),
    (ou(1500), 1.0, {"Z_BELOW_ENTRY"}),
    (ou(1500, phi=1.0, seed=0), 60.0, {"NON_STATIONARY", "NOT_MEAN_REVERTING"}),
])
def test_rejections(vals, spread, reasons):
    a, b = pair(spread)
    assert scan_cross_exchange_basis(a, b, series(vals), 1000.0, NOW).reject_reason in reasons


def test_layered_defense_against_random_walks():
    # single DF test at 5% passes ~6% of random walks; the full gate stack must do far better
    a, b = pair(60.0)
    emitted = sum(
        scan_cross_exchange_basis(a, b, series(ou(1500, phi=1.0, seed=sd)), 1000.0, NOW)
        .opportunity is not None for sd in range(60))
    assert emitted <= 2
    genuine = sum(
        scan_cross_exchange_basis(a, b, series(ou(1500, seed=sd)), 1000.0, NOW)
        .opportunity is not None for sd in range(20))
    assert genuine >= 18


def test_regime_change_rejected_as_unstable():
    vals = ou(750, phi=0.9, seed=6) + ou(750, phi=0.998, seed=7)
    a, b = pair(60.0)
    got = scan_cross_exchange_basis(a, b, series(vals), 1000.0, NOW).reject_reason
    assert got in ("UNSTABLE_RELATIONSHIP", "NON_STATIONARY", "NO_HISTORICAL_CONVERGENCE",
                   "HALF_LIFE_TOO_LONG", "NOT_MEAN_REVERTING")


def test_slow_half_life_rejected():
    cfg = BasisConfig(hold_hours=0.05, min_obs=200)
    a, b = pair(60.0)
    got = scan_cross_exchange_basis(a, b, series(ou(1500)), 1000.0, NOW, cfg).reject_reason
    assert got == "HALF_LIFE_TOO_LONG"


def test_depth_and_pair_rejections():
    a, b = pair(60.0)
    assert scan_cross_exchange_basis(a, b, series(ou(1500)), 5e7, NOW).reject_reason == (
        "INSUFFICIENT_TOP_OF_BOOK_DEPTH")
    assert scan_cross_exchange_basis(a, a, series(ou(1500)), 1000.0, NOW).reject_reason == (
        "NOT_A_CROSS_VENUE_PAIR")


def test_funding_cost_charged_but_benefit_not_credited():
    a, b = pair(60.0)
    pay = scan_cross_exchange_basis(a, b, series(ou(1500)), 1000.0, NOW,
                                    funding_received_bps_per_hour=-2.0).opportunity
    rec = scan_cross_exchange_basis(a, b, series(ou(1500)), 1000.0, NOW,
                                    funding_received_bps_per_hour=+2.0).opportunity
    assert pay.costs.hold_funding_cost == pytest.approx(8.0) and rec.costs.hold_funding_cost == 0


def test_scanner_aggregates_basis():
    a, b = pair(60.0)
    key = ("BTC", "gate", "okx")
    res = OpportunityScanner().scan([a, b], [], 1000.0, NOW, basis_series={key: series(ou(1500))})
    fams = {o.family.value for o in OpportunityScanner.opportunities(res)}
    assert "CROSS_EXCHANGE_BASIS_V1" in fams
