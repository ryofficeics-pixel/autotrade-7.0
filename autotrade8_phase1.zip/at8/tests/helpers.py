from autotrade8.opportunity import (
    CostBreakdown,
    Family,
    Leg,
    Lifecycle,
    Opportunity,
    Side,
    VenueHealth,
)
from autotrade8.sentry import SentryContext

NOW = 1_000.0


def make_opp(oid="o1", family=Family.FUNDING_CARRY, gross=60.0, cost_each=5.0, notional=1000.0,
             capital=1000.0, hold=8 * 3600, life=Lifecycle.PAPER_ACTIVE, **kw):
    costs = CostBreakdown(entry_fees=cost_each, exit_fees=cost_each, risk_buffer=0.0)
    d = {
        "opportunity_id": oid, "family": family, "strategy_version": "v1", "parameter_version": "p1",
        "discovered_at": NOW, "valid_until": NOW + 60,
        "legs": (Leg("gate", "BTC-SPOT", Side.LONG, 0.01, 50000.0),
              Leg("gate", "BTC-PERP", Side.SHORT, 0.01, 50000.0)),
        "gross_expected_edge_bps": gross, "costs": costs, "notional_usd": notional,
        "required_capital": capital, "expected_holding_seconds": hold,
        "directional_delta_usd": 0.0, "gross_exposure_usd": 1000.0,
        "liquidity_score": 0.9, "execution_quality": 0.9, "data_quality": 0.95, "evidence_score": 0.8,
        "estimated_max_loss": 5.0, "lifecycle": life,
    }
    d.update(kw)
    return Opportunity(**d)


def make_ctx(**kw):
    d = {"now": NOW, "equity": 1000.0, "available_capital": 1000.0,
             "venue_health": {"gate": VenueHealth.HEALTHY}}
    d.update(kw)
    return SentryContext(**d)
