import pytest

from autotrade8.allocator import CapitalAllocator, CapitalLedger
from autotrade8.funding import conservative_received_rate, settlements_in_hold
from autotrade8.opportunity import Lifecycle
from autotrade8.scanner import (
    BookTop,
    OpportunityScanner,
    PerpSnapshot,
    SpotSnapshot,
    scan_cross_exchange_funding,
    scan_funding_carry,
)
from autotrade8.sentry import evaluate
from tests.helpers import make_ctx

NOW = 1000.0
BOOK = BookTop(49_990.0, 50_010.0, 5.0, 5.0)


def perp(venue="gate", hist=(0.003,) * 8, interval=8.0, tt=7200.0, ts=NOW, fee=2.0, book=BOOK):
    return PerpSnapshot(venue, "BTC-PERP", "BTC", ts, book, 50_000.0, 50_000.0, hist[-1],
                        interval, NOW + tt, tuple(hist), fee)


def spot(venue="gate", ts=NOW, fee=2.0):
    return SpotSnapshot(venue, "BTC-SPOT", "BTC", ts, BOOK, fee)


def test_helpers():
    assert settlements_in_hold(24 * 3600, 7200, 8) == 3
    assert settlements_in_hold(3600, 7200, 8) == 0
    assert settlements_in_hold(24 * 3600, 1800, 1) == 24
    assert conservative_received_rate(0.002, 0.001, short=True) == 0.001
    assert conservative_received_rate(0.002, 0.001, short=False) == -0.002


def test_carry_emits_opportunity_and_clears_when_promoted():
    r = scan_funding_carry(perp(), spot(), 1000.0, NOW)
    assert r.reject_reason is None
    o = r.opportunity
    assert o.gross_expected_edge_bps == pytest.approx(90.0)
    assert o.expected_net_edge_bps > 0 and o.edge_cost_ratio >= 3.0
    assert abs(o.directional_delta_usd) / o.gross_exposure_usd < 0.02
    assert o.lifecycle is Lifecycle.EXPERIMENTAL
    evaluate(o, make_ctx(now=NOW))
    assert not o.executable and o.sentry.first_rejection_reason.startswith("ALPHA_NOT_PROMOTED")
    assert not any("EDGE" in f or "COST" in f or "DATA" in f for f in o.sentry.all_failures)
    o.lifecycle = Lifecycle.PAPER_ACTIVE
    assert evaluate(o, make_ctx(now=NOW, equity=5000.0, available_capital=5000.0)).state == "CLEARED"
    d = CapitalAllocator(CapitalLedger(5000.0)).decide([o])
    assert d.action == "ALLOCATE" and d.target is o
    small = evaluate(o, make_ctx(now=NOW))  # $1000 account cannot fund 2 x $1000 legs
    assert small.first_rejection_reason == "INSUFFICIENT_AVAILABLE_CAPITAL"


def test_thin_carry_blocked_by_costs():
    o = scan_funding_carry(perp(hist=(0.0001,) * 8, fee=5.0), spot(fee=5.0), 1000.0, NOW).opportunity
    o.lifecycle = Lifecycle.PAPER_ACTIVE
    r = evaluate(o, make_ctx(now=NOW))
    assert r.state == "BLOCKED" and r.first_rejection_reason == "NET_EDGE_NOT_POSITIVE"


@pytest.mark.parametrize("kw,reason", [
    ({"hist": (0.001,) * 4}, "INSUFFICIENT_FUNDING_HISTORY"),
    ({"hist": (-0.001,) * 8}, "NO_POSITIVE_EXPECTED_FUNDING"),
    ({"hist": (0.003, -0.002, 0.004, -0.003, 0.002, 0.001, 0.003, 0.002)},
     "FUNDING_PERSISTENCE_LOW"),
    ({"tt": 30 * 3600.0, "interval": 48.0}, "NO_SETTLEMENT_IN_HOLD"),
])
def test_carry_rejections(kw, reason):
    assert scan_funding_carry(perp(**kw), spot(), 1000.0, NOW).reject_reason == reason


def test_carry_depth_and_venue_rejections():
    assert scan_funding_carry(perp(), spot(), 1_000_000.0, NOW).reject_reason == (
        "INSUFFICIENT_TOP_OF_BOOK_DEPTH")
    assert scan_funding_carry(perp("okx"), spot(), 1000.0, NOW).reject_reason == (
        "SPOT_PERP_VENUE_MISMATCH")


def test_persistence_low_rejected():
    noisy = (0.004, 0.0001, 0.004, 0.0001, 0.004, 0.0001, 0.004, 0.004, 0.0001, 0.004)
    r = scan_funding_carry(perp(hist=noisy), spot(), 1000.0, NOW)
    assert r.reject_reason == "FUNDING_PERSISTENCE_LOW"


def test_stale_and_skewed_data_flows_to_sentry():
    o = scan_funding_carry(perp(ts=NOW - 0.5), spot(ts=NOW), 1000.0, NOW).opportunity
    assert o.cross_venue_timestamp_skew_ms == pytest.approx(500.0)
    o.lifecycle = Lifecycle.PAPER_ACTIVE
    assert evaluate(o, make_ctx(now=NOW)).first_rejection_reason == "CROSS_VENUE_TIMESTAMP_SKEW"


def test_cross_funding_interval_normalized_edge():
    a = perp("gate", hist=(0.003,) * 8, interval=8.0, tt=7200.0)
    b = perp("okx", hist=(0.0001,) * 8, interval=1.0, tt=1800.0)
    r = scan_cross_exchange_funding(a, b, 1000.0, NOW)
    o = r.opportunity
    assert o.gross_expected_edge_bps == pytest.approx(3 * 30 - 24 * 1)
    assert [leg.venue for leg in o.legs] == ["gate", "okx"]
    assert [leg.side.value for leg in o.legs] == ["SHORT", "LONG"]
    r2 = scan_cross_exchange_funding(b, a, 1000.0, NOW)  # order-independent orientation
    assert r2.opportunity.gross_expected_edge_bps == pytest.approx(66.0)
    assert [leg.venue for leg in r2.opportunity.legs] == ["gate", "okx"]


def test_cross_funding_equal_hourly_rates_is_no_edge():
    a = perp("gate", hist=(0.0008,) * 8, interval=8.0, tt=7200.0)
    b = perp("okx", hist=(0.0001,) * 8, interval=1.0, tt=1800.0)
    r = scan_cross_exchange_funding(a, b, 1000.0, NOW)
    assert r.reject_reason == "NO_FUNDING_DIFFERENTIAL"


def test_cross_funding_adverse_entry_gap_costs_basis():
    rich = BookTop(50_100.0, 50_120.0, 5.0, 5.0)  # long venue priced above short venue
    a = perp("gate", hist=(0.003,) * 8)
    b = perp("okx", hist=(0.0,) * 6 + (0.0, 0.0), book=rich)
    o = scan_cross_exchange_funding(a, b, 1000.0, NOW).opportunity
    assert o.costs.hold_basis_drift > 5.0


def test_scanner_aggregates_and_never_orders():
    s = OpportunityScanner()
    res = s.scan([perp("gate"), perp("okx", hist=(0.0001,) * 8)], [spot("gate")], 1000.0, NOW)
    fams = {o.family.value for o in s.opportunities(res)}
    assert fams == {"FUNDING_CARRY_V1", "CROSS_EXCHANGE_FUNDING_V1"}
    assert not hasattr(s, "submit") and not hasattr(s, "place_order")
