import pytest

from autotrade8.onchain import (
    SOCIAL_DATA_UNAVAILABLE,
    Component,
    EventInput,
    EventType,
    GuardData,
    RailState,
    attention_velocity,
    fuse,
    guard,
    hound,
    rail,
    shadow_record,
    survivorship_check,
    wallet_alpha_score,
)

NOW = 10_000.0
SAFE = GuardData(False, 50.0, 50.0, False, False, False, False, True, 30.0, 5.0)


def test_hound_new_alone_scores_nothing_and_stale_rejected():
    bare = hound(EventInput("T", EventType.NEW_LISTING, NOW - 10), NOW)
    assert bare.status == "NO_ACCELERATION_METRICS" and bare.score is None
    assert hound(EventInput("T", EventType.NEW_POOL, NOW - 5000, volume_z=6), NOW).status == (
        "EVENT_STALE")
    assert hound(EventInput("T", EventType.NEW_POOL, NOW + 5, volume_z=6), NOW).status == (
        "EVENT_IN_FUTURE")
    ok = hound(EventInput("T", EventType.VOLUME_ACCELERATION, NOW - 90, volume_z=3.0), NOW)
    assert ok.status == "OK" and ok.score == pytest.approx(0.75 * 0.9)


def test_wallet_score_needs_sample_and_deflates_for_selection():
    assert wallet_alpha_score([50.0] * 10, 100).status == "INSUFFICIENT_WALLET_HISTORY"
    rets = [80.0, -40.0, 60.0, -20.0, 90.0, -30.0] * 8  # 48 trades, positive mean
    few = wallet_alpha_score(rets, wallets_screened=2)
    many = wallet_alpha_score(rets, wallets_screened=100_000)
    assert few.score > many.score  # same wallet, more screening => less credit
    assert many.detail["selection_hurdle"] > few.detail["selection_hurdle"]
    assert survivorship_check(100.0, 20.0) == "SURVIVORSHIP_DEGRADATION"
    assert survivorship_check(100.0, 70.0) == "OK" and survivorship_check(-1, 5) == "NO_PAST_EDGE"


def test_tide_never_fabricates_social_data():
    assert attention_velocity(None, 0.1).status == SOCIAL_DATA_UNAVAILABLE
    assert attention_velocity([5, 18], 0.1).status == "INSUFFICIENT_SOCIAL_HISTORY"
    assert attention_velocity([5] * 6 + [150], None).status == "BOT_SHARE_UNKNOWN"
    assert attention_velocity([5] * 6 + [150], 0.8).score == 0.0
    hot = attention_velocity([5, 5, 5, 5, 5, 5, 150], 0.1)
    steady = attention_velocity([5000] * 7, 0.1)
    assert hot.score > 0.9 and steady.score == 0.0  # change, not popularity


def book(px, size, n=5, step=0.001):
    return [(px * (1 + i * step), size) for i in range(n)]


def test_rail_depends_on_edge_and_exit_liquidity():
    asks, bids = book(1.0, 1000.0), [(1.0 * (1 - i * 0.001), 1000.0) for i in range(5)]
    c, s = rail(asks, bids, 500.0, expected_edge_bps=300.0)
    assert s is RailState.EXECUTABLE and c.score == 1.0
    _, s2 = rail(asks, bids, 3500.0, expected_edge_bps=30.0)
    assert s2 is RailState.REJECTED  # same book, small edge: slippage kills it
    c3, s3 = rail(asks, [], 500.0, 300.0)
    assert s3 is RailState.REJECTED and c3.status == "NO_DEPTH_OR_EXIT_LIQUIDITY"
    big = rail(asks, bids, 10_000_000.0, 300.0)[1]
    assert big is RailState.REJECTED  # cannot fill at all


def test_guard_missing_data_is_no_trade():
    assert guard(SAFE).status == "OK"
    r = guard(GuardData())
    assert r.status == "GUARD_DATA_MISSING" and "honeypot" in r.detail["missing"]
    partial = GuardData(**{**SAFE.__dict__, "lp_locked_or_burned": None})
    assert guard(partial).status == "GUARD_DATA_MISSING"
    bad = GuardData(**{**SAFE.__dict__, "honeypot": True, "sell_tax_bps": 900.0})
    g = guard(bad)
    assert g.status == "BLOCKED" and "HONEYPOT" in g.detail["reasons"] and "SELL_TAX_HIGH" in g.detail["reasons"]


def comps(**over):
    base = {
        "HOUND": Component("HOUND", "OK", 0.8), "ECHO": Component("ECHO", "OK", 0.6),
        "TIDE": Component("TIDE", "OK", 0.7), "RAIL": Component("RAIL", "OK", 1.0),
        "GUARD": guard(SAFE),
    }
    base.update(over)
    return base


def test_fusion_gates_and_missing_not_imputed():
    r = fuse(comps(), RailState.EXECUTABLE)
    assert r.state == "CANDIDATE" and 0 < r.candidate_quality <= 1 and r.n_scored == 5
    assert fuse(comps(GUARD=guard(GuardData())), RailState.EXECUTABLE).reason == (
        "GUARD:GUARD_DATA_MISSING")
    assert fuse(comps(), RailState.DEGRADED).reason == "RAIL:DEGRADED"
    no_social = fuse(comps(TIDE=attention_velocity(None, None)), RailState.EXECUTABLE)
    assert no_social.state == "CANDIDATE" and no_social.n_scored == 4
    thin = fuse({"GUARD": guard(SAFE), "HOUND": Component("HOUND", "OK", 0.9)},
                None, enabled=frozenset({"HOUND", "GUARD"}))
    assert thin.reason == "INSUFFICIENT_COMPONENTS"


def test_shadow_record_is_never_executable_and_logs_ablation():
    rec = shadow_record("TOKEN", NOW, comps(), RailState.EXECUTABLE)
    assert rec.executable is False and rec.fusion.state == "CANDIDATE"
    assert len(rec.ablation) == 5
    assert rec.ablation["HOUND"] == pytest.approx(0.8)
    assert not hasattr(rec, "expected_move_bps")  # unvalidated by construction
