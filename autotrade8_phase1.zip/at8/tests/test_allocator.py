import pytest

from autotrade8.allocator import (
    ActivePosition,
    CapitalAllocator,
    CapitalError,
    CapitalLedger,
    opportunity_score,
    replacement_edge_usd,
)
from autotrade8.sentry import evaluate
from tests.helpers import make_ctx, make_opp


def cleared(oid, gross, **kw):
    o = make_opp(oid, gross=gross, **kw)
    evaluate(o, make_ctx())
    return o


def test_ledger_lifecycle_and_no_double_allocation():
    L = CapitalLedger(1000)
    L.reserve("a", 600)
    assert L.available == 400 and L.state_of("a") == "RESERVED"
    with pytest.raises(CapitalError):
        L.reserve("b", 600)  # same dollars can't be reused
    with pytest.raises(CapitalError):
        L.reserve("a", 10)
    L.deploy("a")
    L.begin_release("a")
    assert L.state_of("a") == "RELEASE_PENDING" and L.available == 400
    L.complete_release("a", realized_pnl=5)
    assert L.available == 1005 and L.state_of("a") == "AVAILABLE"


def test_ledger_illegal_moves():
    L = CapitalLedger(100)
    with pytest.raises(CapitalError):
        L.deploy("x")
    L.reserve("x", 10)
    with pytest.raises(CapitalError):
        L.begin_release("x")


def test_cash_when_nothing_qualifies():
    A = CapitalAllocator(CapitalLedger(1000))
    d = A.decide([make_opp("blocked")])  # never passed SENTRY
    assert d.action == "CASH" and d.reason == "NO_QUALIFIED_EDGE" and d.target is None


def test_cash_when_score_below_hurdle():
    A = CapitalAllocator(CapitalLedger(1000))
    weak = cleared("w", gross=25.0 + 10.0 * 0 + 6.0, hold=30 * 86400)
    assert opportunity_score(weak).score < A.cfg.cash_hurdle_score
    assert A.decide([weak]).action == "CASH"


def test_best_is_allocated_and_one_bundle_max():
    A = CapitalAllocator(CapitalLedger(1000))
    lo, hi = cleared("lo", 40.0), cleared("hi", 90.0)
    d = A.decide([lo, hi])
    assert d.action == "ALLOCATE" and d.target.opportunity_id == "hi"
    A.commit(d)
    with pytest.raises(CapitalError):
        A.commit(A.decide([lo]))


def test_hysteresis_and_switch():
    A = CapitalAllocator(CapitalLedger(1000))
    cur = ActivePosition("cur", remaining_value_usd=4.0, exit_cost_usd=0.5)
    barely = cleared("n1", 60.0)  # net pnl 5.0
    assert A.decide([barely], cur).action == "HOLD"
    much = cleared("n2", 200.0)  # net pnl 19.0
    d = A.decide([much], cur)
    assert d.action == "SWITCH" and d.replacement_edge_usd == pytest.approx(19 - 4 - 0.5)


def test_replacement_edge_formula():
    assert replacement_edge_usd(10, 3, 1, 2) == 4
