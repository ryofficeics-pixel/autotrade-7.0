"""Causal breakout backtester + chronological evaluation. Research only (no order authority).

Signal on the CLOSED bar t -> entry at OPEN of t+1. Stop is checked before runner inside a
bar (conservative). One position at a time. Costs come from ExecInfo, doubled under stress.
"""
from __future__ import annotations

import statistics
from dataclasses import dataclass

from .breakout import (
    BreakoutConfig,
    ExecInfo,
    MoveEstimate,
    atr,
    classify_regime,
    scan_breakout,
)
from .lifecycle import EligibilityMetrics
from .validation import chrono_split
from .volume_zone import Bar

EVIDENCE_VERSION = "EVIDENCE_V1"


@dataclass(frozen=True)
class Trade:
    symbol: str
    signal_idx: int
    entry_idx: int
    exit_idx: int
    entry_price: float
    exit_price: float
    exit_reason: str
    gross_bps: float
    mae_bps: float
    mfe_bps: float
    bars_held: int


def simulate_exit(symbol: str, bars: list[Bar], signal_idx: int, atr_val: float,
                  cfg: BreakoutConfig, max_hold_bars: int) -> Trade | None:
    e = signal_idx + 1
    if e >= len(bars):
        return None
    entry = bars[e].o
    stop = entry - cfg.stop_atr * atr_val
    runner = entry + cfg.runner_atr * atr_val
    mfe_p = mae_p = entry
    last = min(len(bars), e + max_hold_bars)
    for j in range(e, last):
        b = bars[j]
        held = j - e + 1
        mfe_p, mae_p = max(mfe_p, b.h), min(mae_p, b.l)
        reason, px = None, 0.0
        if b.l <= stop:
            reason, px = "STOP", min(stop, b.o)
        elif b.h >= runner:
            reason, px = "RUNNER", runner
        elif held >= cfg.time_stop_bars and mfe_p < entry + atr_val:
            reason, px = "TIME_STOP", b.c  # expansion failed
        elif held >= max_hold_bars:
            reason, px = "MAX_HOLD", b.c
        if reason:
            return Trade(symbol, signal_idx, e, j, entry, px, reason,
                         (px - entry) / entry * 1e4, (mae_p - entry) / entry * 1e4,
                         (mfe_p - entry) / entry * 1e4, held)
    return None  # unresolved at end of data: dropped, never marked-to-market optimistically


def run_backtest(universe: dict[str, list[Bar]], execs: dict[str, ExecInfo], btc: str,
                 cfg: BreakoutConfig, warmup: int = 80, max_hold_bars: int = 12,
                 notional: float = 1000.0) -> list[Trade]:
    t_len = min(len(v) for v in universe.values())
    trades: list[Trade] = []
    busy_until = -1
    for t in range(warmup, t_len - 1):
        if t < busy_until:
            continue
        sl = {s: b[: t + 1] for s, b in universe.items()}
        above = sum(
            1 for b in sl.values()
            if b[-1].c > statistics.fmean(x.c for x in b[-cfg.sma_n:])
        )
        regime = classify_regime(sl[btc], above / len(sl), cfg)
        res = scan_breakout(sl, execs, regime, sl[btc][-1].ts, notional, None, cfg,
                            signals_only=True)
        sigs = [(s, r) for s, r in res.items() if r.reject_reason is None]
        if not sigs:
            continue
        sym, _r = max(sigs, key=lambda sr: float(sr[1].details["z"]))
        a = atr(sl[sym], cfg.atr_slow)
        assert a is not None
        tr = simulate_exit(sym, universe[sym], t, a, cfg, max_hold_bars)
        if tr is not None:
            trades.append(tr)
            busy_until = tr.exit_idx
    return trades


def net_bps(tr: Trade, ex: ExecInfo, bar_hours: float = 1.0, cost_mult: float = 1.0,
            extra_bps: float = 0.0) -> float:
    cost = 2 * (ex.fee_bps + ex.half_spread_bps + ex.slippage_bps)
    cost += max(0.0, ex.funding_bps_per_hour) * tr.bars_held * bar_hours
    return tr.gross_bps - cost * cost_mult - extra_bps


def _mean(x: list[float]) -> float:
    return statistics.fmean(x) if x else 0.0


def profit_factor(nets: list[float]) -> float:
    gains = sum(n for n in nets if n > 0)
    losses = -sum(n for n in nets if n < 0)
    return float("inf") if losses == 0 and gains > 0 else (gains / losses if losses else 0.0)


def max_drawdown_bps(nets: list[float]) -> float:
    peak = cur = dd = 0.0
    for n in nets:
        cur += n
        peak = max(peak, cur)
        dd = max(dd, peak - cur)
    return dd


def estimate_move(selection_trades: list[Trade]) -> MoveEstimate | None:
    """Realized median gross move from SELECTION trades only. evidence = EVIDENCE_V1
    (min(1, n/100) x share of positive gross trades) - NOT a probability."""
    if not selection_trades:
        return None
    g = [t.gross_bps for t in selection_trades]
    share = sum(1 for x in g if x > 0) / len(g)
    return MoveEstimate(len(g), statistics.median(g), min(1.0, len(g) / 100.0) * share)


@dataclass
class EvalReport:
    n: dict[str, int]
    net: dict[str, float]  # mean net bps per segment
    gross_all: float
    net_all: float
    pf: float
    dd_pct: float
    concentration_pct: float
    stress_net: float
    n_total: int
    oos_net: float


def evaluate(trades: list[Trade], execs: dict[str, ExecInfo], total_bars: int,
             max_hold_bars: int, embargo: int) -> EvalReport:
    seg = chrono_split(total_bars, purge=max_hold_bars, embargo=embargo)
    by_seg: dict[str, list[Trade]] = {k: [] for k in seg}
    for t in trades:
        for name, (a, b) in seg.items():
            if a <= t.entry_idx and t.exit_idx < b:
                by_seg[name].append(t)
                break
    nets = {k: [net_bps(t, execs[t.symbol]) for t in v] for k, v in by_seg.items()}
    used = [t for v in by_seg.values() for t in v]
    all_nets = [net_bps(t, execs[t.symbol]) for t in sorted(used, key=lambda x: x.entry_idx)]
    oos = [t for k in ("VALIDATION", "TEST", "HOLDOUT") for t in by_seg[k]]
    stress = [net_bps(t, execs[t.symbol], cost_mult=2.0, extra_bps=5.0) for t in oos]
    pos_by_sym: dict[str, float] = {}
    for t in used:
        n = net_bps(t, execs[t.symbol])
        if n > 0:
            pos_by_sym[t.symbol] = pos_by_sym.get(t.symbol, 0.0) + n
    tot_pos = sum(pos_by_sym.values())
    conc = 100.0 if tot_pos == 0 else max(pos_by_sym.values()) / tot_pos * 100.0
    return EvalReport(
        n={k: len(v) for k, v in by_seg.items()},
        net={k: _mean(v) for k, v in nets.items()},
        gross_all=_mean([t.gross_bps for t in used]), net_all=_mean(all_nets),
        pf=profit_factor(all_nets), dd_pct=max_drawdown_bps(all_nets) / 100.0,
        concentration_pct=conc, stress_net=_mean(stress), n_total=len(used),
        oos_net=_mean([x for k in ("VALIDATION", "TEST", "HOLDOUT") for x in nets[k]]),
    )


def parameter_stability(reports: list[EvalReport], min_n: int = 30) -> bool:
    """Stable only if EVERY neighborhood variant has enough trades and positive OOS net."""
    return bool(reports) and all(r.n_total >= min_n and r.oos_net > 0 for r in reports)


def to_eligibility(r: EvalReport, parameter_stable: bool,
                   execution_model_credible: bool = False) -> EligibilityMetrics:
    """Convert bps-based report (per-trade means). Execution credibility defaults to False
    until PAPER calibration exists; nothing becomes eligible on backtest alone."""
    return EligibilityMetrics(
        n_independent=r.n_total, gross_expectancy=r.gross_all, net_expectancy=r.net_all,
        profit_factor=r.pf, validation_net=r.net["VALIDATION"], test_net=r.net["TEST"],
        holdout_net=r.net["HOLDOUT"], stress_net=r.stress_net, max_drawdown_pct=r.dd_pct,
        max_concentration_pct=r.concentration_pct, parameter_stable=parameter_stable,
        execution_model_credible=execution_model_credible,
    )
