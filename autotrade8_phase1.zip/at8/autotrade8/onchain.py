"""ONCHAIN_EVENT_MOMENTUM_V1 - SHADOW ONLY interfaces (HOUND/ECHO/TIDE/RAIL/GUARD/fusion).

Deterministic and auditable. Missing data is reported, never imputed. Scores are
evidence scores, NOT probabilities. Nothing here can produce an executable Opportunity:
the expected move is unvalidated by construction until forward shadow data exists.
"""
from __future__ import annotations

import math
import statistics
from dataclasses import dataclass, field
from enum import Enum

SOCIAL_DATA_UNAVAILABLE = "SOCIAL_DATA_UNAVAILABLE"
FUSION_VERSION = "FUSION_V1"
FUSION_WEIGHTS = {"event": 0.25, "wallet": 0.25, "attention": 0.20, "liquidity": 0.15,
                  "execution": 0.15}
COMPONENTS = ("HOUND", "ECHO", "TIDE", "RAIL", "GUARD")


def _clamp(x: float) -> float:
    return max(0.0, min(1.0, x))


@dataclass(frozen=True)
class Component:
    name: str
    status: str  # OK | <reason>
    score: float | None = None
    detail: dict[str, float | str] = field(default_factory=dict)


# ---------------------------------------------------------------- HOUND
class EventType(str, Enum):
    NEW_LISTING = "NEW_LISTING"
    NEW_POOL = "NEW_POOL"
    FRESH_MINT = "FRESH_MINT"
    LIQUIDITY_CREATED = "LIQUIDITY_CREATED"
    LIQUIDITY_EXPANSION = "LIQUIDITY_EXPANSION"
    TX_ACCELERATION = "TX_ACCELERATION"
    VOLUME_ACCELERATION = "VOLUME_ACCELERATION"


@dataclass(frozen=True)
class EventInput:
    asset_id: str
    event_type: EventType
    ts: float
    tx_rate_z: float | None = None
    volume_z: float | None = None
    liquidity_change_pct: float | None = None


def hound(ev: EventInput, now: float, max_age_s: float = 900.0) -> Component:
    """Event discovery: a candidate generator. Newness alone scores nothing."""
    age = now - ev.ts
    if age < 0:
        return Component("HOUND", "EVENT_IN_FUTURE")
    if age > max_age_s:
        return Component("HOUND", "EVENT_STALE", None, {"age_s": age})
    metrics = [z / 4.0 for z in (ev.tx_rate_z, ev.volume_z) if z is not None]
    if ev.liquidity_change_pct is not None:
        metrics.append(ev.liquidity_change_pct / 100.0)
    if not metrics:
        return Component("HOUND", "NO_ACCELERATION_METRICS", None, {"age_s": age})
    fresh = 1.0 - age / max_age_s
    return Component("HOUND", "OK", _clamp(max(metrics)) * fresh,
                     {"age_s": age, "freshness": fresh})


# ---------------------------------------------------------------- ECHO
def wallet_alpha_score(net_returns_bps: list[float], wallets_screened: int,
                       min_trades: int = 30) -> Component:
    """WALLET_ALPHA_SCORE (not a probability). t-stat of realized net returns, deflated by the
    expected maximum t among `wallets_screened` null wallets (selection/survivorship bias)."""
    n = len(net_returns_bps)
    if n < min_trades:
        return Component("ECHO", "INSUFFICIENT_WALLET_HISTORY", None, {"n": n})
    sd = statistics.stdev(net_returns_bps)
    if sd == 0:
        return Component("ECHO", "ZERO_VARIANCE_HISTORY", None, {"n": n})
    t = statistics.fmean(net_returns_bps) / (sd / math.sqrt(n))
    hurdle = math.sqrt(2.0 * math.log(max(wallets_screened, 2)))
    return Component("ECHO", "OK", _clamp((t - hurdle) / 3.0),
                     {"t_stat": t, "selection_hurdle": hurdle, "n": n})


def survivorship_check(past_mean_bps: float, forward_mean_bps: float,
                       min_retention: float = 0.5) -> str:
    """Wallets picked on PAST performance must retain a share of it FORWARD."""
    if past_mean_bps <= 0:
        return "NO_PAST_EDGE"
    return "OK" if forward_mean_bps >= min_retention * past_mean_bps else "SURVIVORSHIP_DEGRADATION"


# ---------------------------------------------------------------- TIDE
def attention_velocity(mentions_per_hour: list[float] | None, bot_share: float | None,
                       baseline_n: int = 6) -> Component:
    """Change in attention, not popularity. None => SOCIAL_DATA_UNAVAILABLE (never fabricated)."""
    if mentions_per_hour is None:
        return Component("TIDE", SOCIAL_DATA_UNAVAILABLE)
    if len(mentions_per_hour) < baseline_n + 1:
        return Component("TIDE", "INSUFFICIENT_SOCIAL_HISTORY")
    if bot_share is None:
        return Component("TIDE", "BOT_SHARE_UNKNOWN")
    if bot_share > 0.5:
        return Component("TIDE", "OK", 0.0, {"bot_share": bot_share})
    base = max(statistics.median(mentions_per_hour[-baseline_n - 1:-1]), 1.0)
    growth = mentions_per_hour[-1] / base
    return Component("TIDE", "OK", _clamp(math.log(max(growth, 1.0)) / math.log(30.0)),
                     {"growth": growth, "bot_share": bot_share})


# ---------------------------------------------------------------- RAIL
class RailState(str, Enum):
    EXECUTABLE = "EXECUTABLE"
    DEGRADED = "DEGRADED"
    REJECTED = "REJECTED"


def _vwap_slippage_bps(levels: list[tuple[float, float]], notional: float, buy: bool) -> float | None:
    """levels: (price, size) best-first. None if depth cannot fill the notional."""
    if not levels or notional <= 0:
        return None
    left, cost, qty = notional, 0.0, 0.0
    for px, sz in levels:
        take = min(left, px * sz)
        cost += take
        qty += take / px
        left -= take
        if left <= 1e-9:
            break
    if left > 1e-9:
        return None
    vwap = cost / qty
    best = levels[0][0]
    return (vwap - best) / best * 1e4 if buy else (best - vwap) / best * 1e4


def rail(asks: list[tuple[float, float]], bids: list[tuple[float, float]], notional: float,
         expected_edge_bps: float, min_edge_cost: float = 3.0) -> tuple[Component, RailState]:
    """Execution feasibility. Allowed round-trip slippage scales with the expected edge:
    entry+exit slippage must leave edge/cost >= min_edge_cost."""
    buy, sell = _vwap_slippage_bps(asks, notional, True), _vwap_slippage_bps(bids, notional, False)
    if buy is None or sell is None:
        return Component("RAIL", "NO_DEPTH_OR_EXIT_LIQUIDITY", 0.0), RailState.REJECTED
    total = buy + sell
    budget = expected_edge_bps / min_edge_cost
    d: dict[str, float | str] = {"entry_slip_bps": buy, "exit_slip_bps": sell, "budget_bps": budget}
    if total <= budget:
        return Component("RAIL", "OK", 1.0, d), RailState.EXECUTABLE
    if total <= 2 * budget:
        return Component("RAIL", "OK", 0.5, d), RailState.DEGRADED
    return Component("RAIL", "SLIPPAGE_EXCEEDS_EDGE_BUDGET", 0.0, d), RailState.REJECTED


# ---------------------------------------------------------------- GUARD
@dataclass(frozen=True)
class GuardData:
    """None = unknown. Every field is mandatory: unknown safety data means NO TRADE."""
    honeypot: bool | None = None
    buy_tax_bps: float | None = None
    sell_tax_bps: float | None = None
    mint_authority_active: bool | None = None
    freeze_authority_active: bool | None = None
    blacklist_function: bool | None = None
    proxy_upgradeable: bool | None = None
    lp_locked_or_burned: bool | None = None
    top10_holder_pct: float | None = None
    creator_holder_pct: float | None = None


@dataclass(frozen=True)
class GuardLimits:
    max_tax_bps: float = 300.0
    max_top10_pct: float = 60.0
    max_creator_pct: float = 20.0


def guard(g: GuardData, lim: GuardLimits | None = None) -> Component:
    lim = lim or GuardLimits()
    missing = [k for k, v in g.__dict__.items() if v is None]
    if missing:
        return Component("GUARD", "GUARD_DATA_MISSING", 0.0, {"missing": ",".join(missing)})
    bad: list[str] = []
    checks = [
        (g.honeypot, "HONEYPOT"), (g.mint_authority_active, "MINT_AUTHORITY_ACTIVE"),
        (g.freeze_authority_active, "FREEZE_AUTHORITY_ACTIVE"),
        (g.blacklist_function, "BLACKLIST_FUNCTION"), (g.proxy_upgradeable, "PROXY_UPGRADEABLE"),
        (not g.lp_locked_or_burned, "LP_NOT_LOCKED"),
        (g.buy_tax_bps is not None and g.buy_tax_bps > lim.max_tax_bps, "BUY_TAX_HIGH"),
        (g.sell_tax_bps is not None and g.sell_tax_bps > lim.max_tax_bps, "SELL_TAX_HIGH"),
        (g.top10_holder_pct is not None and g.top10_holder_pct > lim.max_top10_pct,
         "HOLDER_CONCENTRATION"),
        (g.creator_holder_pct is not None and g.creator_holder_pct > lim.max_creator_pct,
         "CREATOR_CONCENTRATION"),
    ]
    bad = [name for cond, name in checks if cond]
    if bad:
        return Component("GUARD", "BLOCKED", 0.0, {"reasons": ",".join(bad)})
    return Component("GUARD", "OK", 1.0)


# ---------------------------------------------------------------- fusion
@dataclass(frozen=True)
class FusionResult:
    version: str
    state: str  # CANDIDATE | BLOCKED
    reason: str | None
    candidate_quality: float | None  # evidence score, NOT a probability
    components: dict[str, Component]
    n_scored: int


def fuse(components: dict[str, Component], rail_state: RailState | None,
         enabled: frozenset[str] = frozenset(COMPONENTS), min_components: int = 3) -> FusionResult:
    """Explicit evidence fusion. GUARD and RAIL are gates; the rest are weighted scores.
    Missing scores are excluded (not imputed) and counted."""
    comp = {k: v for k, v in components.items() if k in enabled}
    g = comp.get("GUARD")
    if "GUARD" in enabled and (g is None or g.status != "OK"):
        return FusionResult(FUSION_VERSION, "BLOCKED",
                            f"GUARD:{'MISSING' if g is None else g.status}", None, comp, 0)
    if "RAIL" in enabled and rail_state is not RailState.EXECUTABLE:
        return FusionResult(FUSION_VERSION, "BLOCKED", f"RAIL:{getattr(rail_state, 'value', 'MISSING')}",
                            None, comp, 0)
    parts: dict[str, float] = {}
    if (h := comp.get("HOUND")) and h.score is not None:
        parts["event"] = h.score
    if (e := comp.get("ECHO")) and e.score is not None:
        parts["wallet"] = e.score
    if (t := comp.get("TIDE")) and t.score is not None:
        parts["attention"] = t.score
    if (r := comp.get("RAIL")) and r.score is not None:
        parts["execution"] = r.score
        parts["liquidity"] = r.score
    if len(parts) < min_components:
        return FusionResult(FUSION_VERSION, "BLOCKED", "INSUFFICIENT_COMPONENTS", None, comp,
                            len(parts))
    w = sum(FUSION_WEIGHTS[k] for k in parts)
    q = sum(FUSION_WEIGHTS[k] * v for k, v in parts.items()) / w
    return FusionResult(FUSION_VERSION, "CANDIDATE", None, q, comp, len(parts))


ABLATION_SETS: tuple[frozenset[str], ...] = (
    frozenset({"HOUND"}),
    frozenset({"HOUND", "ECHO"}),
    frozenset({"HOUND", "ECHO", "TIDE"}),
    frozenset({"HOUND", "ECHO", "TIDE", "RAIL"}),
    frozenset({"HOUND", "ECHO", "TIDE", "RAIL", "GUARD"}),
)


@dataclass(frozen=True)
class ShadowRecord:
    """Everything needed for later forward evaluation. Expected move is deliberately absent."""
    asset_id: str
    ts: float
    fusion: FusionResult
    ablation: dict[str, float | None]
    executable: bool = False  # always False: ONCHAIN_EVENT is SHADOW ONLY


def shadow_record(asset_id: str, ts: float, components: dict[str, Component],
                  rail_state: RailState | None) -> ShadowRecord:
    full = fuse(components, rail_state)
    abl = {"+".join(sorted(s)): fuse(components, rail_state, s, min_components=1).candidate_quality
           for s in ABLATION_SETS}
    return ShadowRecord(asset_id, ts, full, abl)
