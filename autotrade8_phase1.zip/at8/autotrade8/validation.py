"""Chronological validation: split, purge/embargo, walk-forward, CPCV, null tests."""
from __future__ import annotations

import random
import statistics
from dataclasses import dataclass
from itertools import combinations
from math import comb

Range = tuple[int, int]  # half-open [start, end)
SPLIT_NAMES = ("SELECTION", "VALIDATION", "TEST", "HOLDOUT")


def chrono_split(
    n: int, fractions: tuple[float, ...] = (0.50, 0.20, 0.15, 0.15),
    purge: int = 0, embargo: int = 0,
) -> dict[str, Range]:
    """Contiguous split, never shuffled. Purge trims each segment's tail, embargo its head."""
    if abs(sum(fractions) - 1.0) > 1e-9 or len(fractions) != 4:
        raise ValueError("need 4 fractions summing to 1")
    bounds = [0]
    acc = 0.0
    for f in fractions[:-1]:
        acc += f
        bounds.append(round(acc * n))
    bounds.append(n)
    out: dict[str, Range] = {}
    for i, name in enumerate(SPLIT_NAMES):
        start = bounds[i] + (embargo if i > 0 else 0)
        end = bounds[i + 1] - (purge if i < 3 else 0)
        if end <= start:
            raise ValueError(f"segment {name} empty after purge/embargo")
        out[name] = (start, end)
    return out


def walk_forward_folds(
    n: int, n_folds: int, min_train: int, purge: int, anchored: bool = True
) -> list[tuple[Range, Range]]:
    """(train, test) pairs; train always ends `purge` bars before the test window."""
    test_size = (n - min_train) // n_folds
    if test_size <= 0:
        raise ValueError("not enough data for requested folds")
    folds = []
    for k in range(n_folds):
        t0 = min_train + k * test_size
        t1 = t0 + test_size
        tr_end = t0 - purge
        tr_start = 0 if anchored else max(0, tr_end - min_train)
        if tr_end <= tr_start:
            raise ValueError("empty training window after purge")
        folds.append(((tr_start, tr_end), (t0, t1)))
    return folds


@dataclass(frozen=True)
class CPCVSplit:
    train: tuple[int, ...]
    test_groups: tuple[int, ...]
    test_ranges: tuple[Range, ...]


def cpcv_splits(n: int, n_groups: int, k_test: int, purge: int, embargo: int) -> list[CPCVSplit]:
    if not 0 < k_test < n_groups or n < n_groups:
        raise ValueError("invalid CPCV configuration")
    edges = [round(i * n / n_groups) for i in range(n_groups + 1)]
    groups = [(edges[i], edges[i + 1]) for i in range(n_groups)]
    splits = []
    for combo in combinations(range(n_groups), k_test):
        ranges = tuple(groups[g] for g in combo)
        banned = bytearray(n)
        for s, e in ranges:
            for i in range(max(0, s - purge), min(n, e + embargo)):
                banned[i] = 1
        splits.append(CPCVSplit(tuple(i for i in range(n) if not banned[i]), combo, ranges))
    return splits


def cpcv_path_count(n_groups: int, k_test: int) -> int:
    return comb(n_groups - 1, k_test - 1)


def cpcv_paths(
    splits: list[CPCVSplit], n_groups: int, k_test: int, results: list[dict[int, float]]
) -> list[float]:
    """Assemble OOS paths: each path takes every group exactly once. results[i][g] = OOS value."""
    per_group: dict[int, list[int]] = {g: [] for g in range(n_groups)}
    for i, sp in enumerate(splits):
        for g in sp.test_groups:
            per_group[g].append(i)
    n_paths = cpcv_path_count(n_groups, k_test)
    return [sum(results[per_group[g][p]][g] for g in range(n_groups)) for p in range(n_paths)]


@dataclass(frozen=True)
class PathSummary:
    n_paths: int
    median: float
    worst: float
    positive_fraction: float
    dispersion: float


def summarize_paths(paths: list[float]) -> PathSummary:
    return PathSummary(
        len(paths), statistics.median(paths), min(paths),
        sum(1 for p in paths if p > 0) / len(paths),
        statistics.pstdev(paths) if len(paths) > 1 else 0.0,
    )


def signflip_null_pvalue(returns: list[float], n_boot: int = 5000, seed: int = 0,
                         min_n: int = 30) -> float | None:
    """P(mean >= observed | zero-mean symmetric null). None => INSUFFICIENT_EVIDENCE."""
    if len(returns) < min_n:
        return None
    rnd = random.Random(seed)
    obs = statistics.fmean(returns)
    hits = 0
    for _ in range(n_boot):
        m = statistics.fmean(r if rnd.random() < 0.5 else -r for r in returns)
        hits += m >= obs
    return (hits + 1) / (n_boot + 1)


def random_pick_null_pvalue(eligible: list[list[float]], chosen: list[float],
                            n_sim: int = 5000, seed: int = 0) -> float:
    """Strategy picks vs random picks from the same eligible sets (funding: random pair)."""
    if len(eligible) != len(chosen) or not chosen:
        raise ValueError("eligible/chosen length mismatch")
    rnd = random.Random(seed)
    obs = statistics.fmean(chosen)
    hits = 0
    for _ in range(n_sim):
        m = statistics.fmean(rnd.choice(pool) for pool in eligible)
        hits += m >= obs
    return (hits + 1) / (n_sim + 1)
