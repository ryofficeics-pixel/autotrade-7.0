"""CROSS_EXCHANGE_BASIS_V1 (SHADOW): executable cross-venue spread mean reversion.

Spread series = mid-based (A-B)/avg-mid in bps, regularly sampled. Statistics are
diagnostics, not proof: every gate is checked on the full history AND on both
chronological halves so in-sample-only relationships are rejected.
"""
from __future__ import annotations

import math
import statistics
from dataclasses import dataclass

from .opportunity import CostBreakdown, Family, Leg, Lifecycle, Opportunity, Side
from .scanner import (
    PerpSnapshot,
    ScannerConfig,
    ScanResult,
    _liquidity,
    _quality,
    _reject,
)

BASIS_PARAM_VERSION = "BASIS_CFG_V1"
DF_CRIT_5PCT = -2.86  # Dickey-Fuller, constant, no trend (asymptotic). NOT augmented.


@dataclass(frozen=True)
class SpreadSeries:
    dt_s: float
    values: tuple[float, ...]  # bps, oldest -> newest, excludes the current snapshot


@dataclass(frozen=True)
class BasisConfig:
    hold_hours: float = 4.0
    window: int = 60
    entry_z: float = 2.0
    exit_z: float = 0.5
    min_obs: int = 200
    min_events: int = 8
    min_converge_rate: float = 0.7
    max_half_life_vs_hold: float = 1.0  # half-life must be <= hold horizon
    half_life_stability: float = 3.0  # halves' half-lives within this factor
    collateral_apr: float = 0.05
    risk_buffer_bps: float = 5.0
    emergency_bps: float = 5.0
    stress_basis_move_bps: float = 50.0


@dataclass(frozen=True)
class MRStats:
    n: int
    phi: float
    mu: float
    half_life_steps: float | None
    df_t: float | None
    stationary: bool


def _ols(x: list[float], y: list[float]) -> tuple[float, float, float] | None:
    n = len(x)
    if n < 4:
        return None
    mx, my = statistics.fmean(x), statistics.fmean(y)
    sxx = sum((xi - mx) ** 2 for xi in x)
    if sxx <= 0:
        return None
    slope = sum((xi - mx) * (yi - my) for xi, yi in zip(x, y, strict=True)) / sxx
    icpt = my - slope * mx
    rss = sum((yi - icpt - slope * xi) ** 2 for xi, yi in zip(x, y, strict=True))
    se = math.sqrt(max(rss, 0.0) / (n - 2) / sxx)
    return slope, icpt, se


def mean_reversion_stats(x: list[float]) -> MRStats | None:
    """AR(1) phi/mu/half-life plus Dickey-Fuller t-statistic."""
    if len(x) < 10:
        return None
    lag, cur = x[:-1], x[1:]
    fit = _ols(lag, cur)
    if fit is None:
        return None
    phi, icpt, _ = fit
    mu = icpt / (1 - phi) if abs(1 - phi) > 1e-12 else statistics.fmean(x)
    hl = -math.log(2) / math.log(phi) if 0 < phi < 1 else None
    df = _ols(lag, [c - lg for c, lg in zip(cur, lag, strict=True)])
    t = None if df is None or df[2] == 0 else df[0] / df[2]
    return MRStats(len(x), phi, mu, hl, t, t is not None and t < DF_CRIT_5PCT)


def rolling_z(x: list[float], t: int, window: int) -> float:
    """Causal z of x[t] against the `window` observations BEFORE t."""
    w = x[t - window:t]
    sd = statistics.pstdev(w)
    return 0.0 if sd == 0 else (x[t] - statistics.fmean(w)) / sd


@dataclass(frozen=True)
class ConvergenceEvents:
    n_events: int
    converge_rate: float
    mean_capture_bps: float


def historical_convergence(x: list[float], window: int, entry_z: float, exit_z: float,
                           max_hold: int) -> ConvergenceEvents:
    """Non-overlapping |z|>=entry events; converged if |z|<=exit within max_hold steps."""
    caps: list[float] = []
    ok = 0
    t = window
    while t < len(x) - 1:
        z = rolling_z(x, t, window)
        if abs(z) < entry_z:
            t += 1
            continue
        sign = 1.0 if z > 0 else -1.0
        end = min(t + max_hold, len(x) - 1)
        exit_i, converged = end, False
        for j in range(t + 1, end + 1):
            if abs(rolling_z(x, j, window)) <= exit_z:
                exit_i, converged = j, True
                break
        caps.append(sign * (x[t] - x[exit_i]))
        ok += converged
        t = exit_i + 1
    if not caps:
        return ConvergenceEvents(0, 0.0, 0.0)
    return ConvergenceEvents(len(caps), ok / len(caps), statistics.fmean(caps))


def _series_gaps_ok(s: SpreadSeries) -> bool:
    return s.dt_s > 0 and all(math.isfinite(v) for v in s.values)


def scan_cross_exchange_basis(
    a: PerpSnapshot, b: PerpSnapshot, series: SpreadSeries, notional: float, now: float,
    cfg: BasisConfig | None = None, base: ScannerConfig | None = None,
    funding_received_bps_per_hour: float = 0.0,
) -> ScanResult:
    cfg, base = cfg or BasisConfig(), base or ScannerConfig()
    if a.venue == b.venue or a.underlying != b.underlying:
        return _reject("NOT_A_CROSS_VENUE_PAIR")
    if not (a.book.valid and b.book.valid):
        return _reject("INVALID_BOOK")
    x = list(series.values)
    if not _series_gaps_ok(series) or len(x) < cfg.min_obs:
        return _reject("INSUFFICIENT_HISTORY", n=len(x))
    full = mean_reversion_stats(x)
    h1, h2 = x[: len(x) // 2], x[len(x) // 2:]
    s1, s2 = mean_reversion_stats(h1), mean_reversion_stats(h2)
    if full is None or s1 is None or s2 is None:
        return _reject("INSUFFICIENT_HISTORY", n=len(x))
    if any(s.half_life_steps is None for s in (full, s1, s2)):
        return _reject("NOT_MEAN_REVERTING", phi=full.phi)
    if not full.stationary:
        return _reject("NON_STATIONARY", df_t=full.df_t if full.df_t is not None else 0.0)
    assert full.half_life_steps and s1.half_life_steps and s2.half_life_steps
    ratio = max(s1.half_life_steps, s2.half_life_steps) / min(s1.half_life_steps, s2.half_life_steps)
    if ratio > cfg.half_life_stability or not (s1.stationary or s2.stationary):
        return _reject("UNSTABLE_RELATIONSHIP", half_life_ratio=ratio)
    hold_s = cfg.hold_hours * 3600.0
    hl_s = full.half_life_steps * series.dt_s
    if hl_s > cfg.max_half_life_vs_hold * hold_s:
        return _reject("HALF_LIFE_TOO_LONG", half_life_s=hl_s)

    max_hold = max(1, int(hold_s / series.dt_s))
    ev1 = historical_convergence(h1, cfg.window, cfg.entry_z, cfg.exit_z, max_hold)
    ev2 = historical_convergence(h2, cfg.window, cfg.entry_z, cfg.exit_z, max_hold)
    for ev in (ev1, ev2):
        if ev.n_events < cfg.min_events // 2 or ev.converge_rate < cfg.min_converge_rate:
            return _reject("NO_HISTORICAL_CONVERGENCE", rate1=ev1.converge_rate,
                           rate2=ev2.converge_rate, n1=ev1.n_events, n2=ev2.n_events)

    avg_mid = (a.book.mid + b.book.mid) / 2
    x_now = (a.book.mid - b.book.mid) / avg_mid * 1e4
    w = x[-cfg.window:]
    sd = statistics.pstdev(w)
    z_now = 0.0 if sd == 0 else (x_now - statistics.fmean(w)) / sd
    if abs(z_now) < cfg.entry_z:
        return _reject("Z_BELOW_ENTRY", z=z_now)
    if (x_now - full.mu) * z_now <= 0:
        return _reject("MEAN_DIRECTION_CONFLICT", z=z_now)

    short, long_ = (a, b) if z_now > 0 else (b, a)
    qty = notional / long_.book.ask
    if qty > long_.book.ask_size or qty > short.book.bid_size:
        return _reject("INSUFFICIENT_TOP_OF_BOOK_DEPTH", qty=qty)

    h_steps = hold_s / series.dt_s
    gross = abs(x_now - full.mu) * (1 - full.phi ** h_steps)  # expected reversion within hold
    fees = short.taker_fee_bps + long_.taker_fee_bps
    hs = short.book.half_spread_bps + long_.book.half_spread_bps
    fund_cost = max(0.0, -funding_received_bps_per_hour * cfg.hold_hours)  # benefit not credited
    costs = CostBreakdown(
        entry_fees=fees, entry_spread=hs, exit_fees=fees, exit_spread=hs,
        hold_funding_cost=fund_cost,
        hold_collateral_opportunity=cfg.collateral_apr * cfg.hold_hours / 8760 * 1e4 * 2,
        hold_basis_drift=cfg.risk_buffer_bps, emergency_hedge_failure=cfg.emergency_bps,
    )
    legs = (
        Leg(short.venue, short.instrument, Side.SHORT, qty, short.book.bid),
        Leg(long_.venue, long_.instrument, Side.LONG, qty, long_.book.ask),
    )
    dq, skew = _quality(now, (a.ts, b.ts), base)
    spread_bps = 2 * hs
    evidence = min(ev1.converge_rate, ev2.converge_rate)
    max_loss_bps = max(cfg.stress_basis_move_bps, 3.0 * sd)
    opp = Opportunity(
        opportunity_id=(f"{Family.CROSS_EXCHANGE_BASIS.value}:{a.underlying}:"
                        f"{short.venue}>{long_.venue}:{int(now)}"),
        family=Family.CROSS_EXCHANGE_BASIS, strategy_version="v1",
        parameter_version=BASIS_PARAM_VERSION, discovered_at=now, valid_until=now + base.max_age_s,
        legs=legs, gross_expected_edge_bps=gross, costs=costs, notional_usd=notional,
        required_capital=2 * notional, expected_holding_seconds=hold_s,
        directional_delta_usd=sum(leg.signed_notional for leg in legs),
        gross_exposure_usd=sum(leg.notional for leg in legs),
        liquidity_score=_liquidity(
            [short.book.bid_size * short.book.bid, long_.book.ask_size * long_.book.ask],
            notional, base),
        execution_quality=max(0.0, 1.0 - spread_bps / 20.0),
        data_quality=dq, evidence_score=evidence,
        risks={"basis": max_loss_bps, "venue": 1.0, "model": 1.0 - evidence},
        estimated_max_loss=notional * max_loss_bps / 1e4,
        lifecycle=Lifecycle.EXPERIMENTAL, cross_venue_timestamp_skew_ms=skew,
    )
    return ScanResult(opp, None, {
        "z": z_now, "x_now_bps": x_now, "mu_bps": full.mu, "phi": full.phi,
        "half_life_s": hl_s, "df_t": full.df_t if full.df_t is not None else 0.0,
        "events_h1": ev1.n_events, "events_h2": ev2.n_events,
        "rate_h1": ev1.converge_rate, "rate_h2": ev2.converge_rate,
        "mean_capture_bps": (ev1.mean_capture_bps + ev2.mean_capture_bps) / 2,
    })
