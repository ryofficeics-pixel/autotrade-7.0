# AUTOTRADE 8.0 FINAL — Implementation Report

**Date:** 2026-09-25
**Scope of this report:** the common economic layer and research engines built in this session
(`autotrade8/`, 2,470 lines, 1,228 lines of tests, 111 tests passing, ruff clean, mypy --strict
clean). This is Phase 1–6 groundwork implemented standalone. It has **not** been merged into an
AUTOTRADE 7 repository, connected to NautilusTrader, or run against real market data.

---

## 1. Executive Summary

Built a multi-alpha capital allocation engine per the spec: a common Opportunity schema, unified
cost model, universal SENTRY risk gate, capital allocator with reservation and switching
hysteresis, a multi-leg hedge state machine, three deterministic alpha engines (funding carry,
cross-exchange funding, cross-exchange basis), one directional engine (cross-sectional breakout
with a causal backtester), a SHADOW-only on-chain event framework (HOUND/ECHO/TIDE/RAIL/GUARD),
and a chronological validation toolkit (splits, walk-forward, CPCV, null tests). No component has
order-submit authority. No component has been fed real data. **Zero strategies are PAPER-eligible.
Zero families have executable evidence. LIVE trading is structurally impossible in this codebase**
— there is no `LIVE` lifecycle state and no execution adapter exists at all.

## 2. AUTOTRADE 7 Baseline

Not independently re-audited in this session — no AUTOTRADE 7 repository or audit reports were
available in this environment. Per the spec's binding evidence (§1), AUTOTRADE 7's primary
directional strategy is treated as having negative net expectancy, sub-1 profit factor, and
insufficient payoff asymmetry; KAMA, Entry V3, and XAU experiments as non-promotable. This report
does not re-verify those figures — it accepts them as given and does not recreate REST Momentum
variants, KAMA variants, or indicator-soup combinations anywhere in this codebase.

## 3. Screenshot/Reference Analysis

No screenshot repository or TensorTrade/Hummingbot/Epsilon-Quant/momentum/autotrade reference
repos were fetched in this session (no network access to GitHub in this sandbox). Design choices
below follow the spec's own filtering of those sources (§102) rather than direct repo inspection.

## 4–5. Accepted / Rejected Ideas

**Accepted:** independent per-family evidence scoring; a universal final risk gate that can say
NO; abstention as a first-class allocator outcome (CASH); execution-feasibility gating scaled to
expected edge rather than a fixed slippage tolerance; volume-derived zones as a gated feature, not
an assumed edge; RL reserved for a future allocator role, never for price prediction.

**Rejected:** fixed confidence scores (0.92-style); wallet win-rate as sufficient evidence;
2%-slippage-is-fine heuristics; indicator combinations as alpha; "more agents = more accurate."

## 6. Architecture

`opportunity.py` (schema/enums) → `scanner.py` / `basis.py` / `breakout.py` / `onchain.py`
(engines, read-only) → `sentry.py` (universal gate) → `allocator.py` (ranking, capital ledger,
hysteresis) → *(execution — not built; Nautilus-owned per spec §17)* → `backtest.py` /
`validation.py` / `lifecycle.py` / `tournament.py` (research/evidence layer). No module imports
an order-submission path; this is checked by test (`test_scanner_aggregates_and_never_orders`,
`ShadowRecord.executable` hardcoded `False`).

## 7. Opportunity Model

`opportunity.py`: `Opportunity` dataclass with `family`, `legs`, `costs` (full `CostBreakdown`),
`gross_expected_edge_bps`, derived `expected_net_edge_bps` / `edge_cost_ratio` /
`expected_net_pnl`, risk fields, `evidence_score`, `lifecycle`, and a `sentry` result carrying
`executable` and `first_rejection_reason`. Matches spec §20 field-for-field; no family gets
special-cased accounting.

## 8. Cost Model

`costs.py` + `CostBreakdown` (entry/hold/exit/emergency bps, spec §21). `edge_cost_ratio`,
`min_movement_bps` (verified against the spec's own example: 17 bps cost → 51 bps minimum move at
ratio 3), and the 2.5/3.0/3.5/4.0 neighborhood check (§22–23) are implemented and tested.
`risk_adjusted_capital_efficiency` (RACE_V1) is a **placeholder formula** (net return per
capital-day × execution quality ÷ (1 + tail ratio)) — not validated against real capital
constraints, and explicitly versioned so it can be replaced without breaking callers.

## 9. Capital Allocator

`allocator.py`: `CapitalLedger` enforces AVAILABLE→RESERVED→DEPLOYED→RELEASE_PENDING→AVAILABLE
(spec §48) and rejects double-reservation of the same opportunity id (tested). `CapitalAllocator`
ranks only SENTRY-cleared opportunities, defaults to CASH when nothing clears a configurable
hurdle score, and applies switching hysteresis (§49) via `replacement_edge_usd`. Default
`max_active_bundles=1` per §47.

## 10. SENTRY

`sentry.py`: 11 gates run to completion every call (no short-circuit) — DATA, LIQUIDITY, ALPHA,
EDGE, COST, EDGE_COST, RISK, CAPITAL, VENUE, EXPOSURE, EXECUTION_PLAN. Reports the first binding
reason plus the full failure list. **Bug found and fixed during testing:** the EXPOSURE gate
originally passed (fail-open) when `gross_exposure_usd == 0`, which would have let an
undefined-delta-percentage opportunity through; it now fails closed with `EXPOSURE_UNDEFINED`.

## 11. Funding Carry (`FUNDING_CARRY_V1`)

`scanner.py::scan_funding_carry` + `funding.py`. Long spot / short perp, funding-positive only
(negative funding would require a spot borrow leg, out of scope). Uses `conservative_received_rate`
(worse of 3- and 6-settlement means) and a deterministic `FUNDING_PERSISTENCE_SCORE`
(sign-persistence × stability, §27). **Evidence: none — synthetic snapshots only.** Default
`min_persistence` was raised from an initial 0.5 to 0.7 after testing showed a noisy-but-
positive-mean history (score 0.56) would otherwise pass; still a placeholder pending real
funding-history calibration.

## 12. Cross-Exchange Funding (`CROSS_EXCHANGE_FUNDING_V1`)

`scanner.py::scan_cross_exchange_funding`. Interval-normalized via `settlements_in_hold` — an 8h
and a 1h venue are never compared on raw per-print rates. Orientation (which venue to short) is
chosen automatically from whichever side has positive net differential; verified
order-independent by test. **Evidence: none.**

## 13. Cross-Exchange Basis (`CROSS_EXCHANGE_BASIS_V1`)

`basis.py`. Mid-based spread series, causal rolling z-score, AR(1) fit for half-life, and a
(non-augmented) Dickey-Fuller t-statistic for stationarity. Every gate is checked on the full
history **and** on both chronological halves, rejecting relationships that only hold in-sample
(`UNSTABLE_RELATIONSHIP`, `NO_HISTORICAL_CONVERGENCE`). Measured false-positive rate: a single DF
test at the 5% level passes ~6% of pure random walks in isolation; the full gate stack
(stationarity + half-life-vs-hold + two-half convergence-rate agreement) reduced this to 1/100 in
this codebase's synthetic test, versus 30/30 for genuinely mean-reverting (OU) series. This is a
property of the synthetic generator, not evidence of real-market performance.

## 14. Cross-Sectional Breakout (`CROSS_SECTIONAL_BREAKOUT_V1`)

`breakout.py` + `backtest.py`. Long-only, one best candidate at a time. Pipeline: liquidity
eligibility → cross-sectional momentum rank → regime permission (TREND_UP only) → volatility
expansion → Donchian breakout → volume participation → optional volume-zone / stochastic context
→ **expected-move validation gate**. This last gate is load-bearing: without a validated
`MoveEstimate` (n≥30 from SELECTION-only backtest trades), the candidate is rejected with
`EXPECTED_MOVE_UNVALIDATED` regardless of how clean the signal looks. `backtest.py` implements
causal entry-at-next-open, conservative same-bar stop/runner resolution, gap-through-stop fill at
open, one-position-at-a-time sequencing, and a chronological evaluator that **discards any trade
straddling a split boundary** (label-leakage prevention). Four ablation variants share one code
path via `BreakoutConfig` flags.

**Honesty check performed:** ran the full backtest on six independent geometric random walks with
realistic costs (5bps fee, 2bps spread, 3bps slippage per side). Result: net expectancy was **not**
positive with adequate sample size in any seed tried — asserted explicitly in
`test_backtest_runs_one_position_at_a_time_and_is_honest_on_noise`. This is the expected and
required outcome for pure noise; it is not evidence the strategy works on real markets, only that
the harness does not manufacture false edge on fake ones.

## 15. Volume Zone Context (Incremental Value)

`volume_zone.py`: causal fractal high/low detection with the standard `n`-bar confirmation delay
(a zone only exists after its confirming bar closes) and relative-volume filtering. Verified by a
prefix-invariance test (300-bar random series): the zone state after `k` bars is bit-identical
whether computed live or by re-running from scratch on the first `k` bars — i.e. no lookahead.
**Incremental value: not measured.** The ablation harness exists (`BreakoutConfig.use_volume_zone`
+ `backtest.py`) but has not been run against real OHLCV, so §37's required ablation comparison is
still open.

## 16. On-Chain Event Architecture

`onchain.py`: HOUND (event discovery — newness alone scores nothing, requires an acceleration
metric), ECHO (`wallet_alpha_score` deflates its t-statistic by `sqrt(2·ln(wallets_screened))` to
penalize survivorship/selection bias explicitly, plus a separate forward-retention check), TIDE
(returns `SOCIAL_DATA_UNAVAILABLE` rather than fabricating data when none is supplied; scores
attention *change*, not absolute volume), RAIL (EXECUTABLE/DEGRADED/REJECTED from VWAP slippage
against an edge-scaled budget, not a fixed 2% heuristic), GUARD (any missing safety field forces
`GUARD_DATA_MISSING`, hence no trade). Evidence fusion excludes missing components rather than
imputing them and requires GUARD=OK and RAIL=EXECUTABLE as hard gates. `ShadowRecord.executable`
is hardcoded `False` — this family cannot produce a live order from this codebase by construction,
independent of any config.

## 17. TensorTrade / RL Decision

Not integrated. No TensorTrade, Ray, or TensorFlow dependency was added. Per spec §16, this is
correctly deferred: no deterministic alpha has cleared PAPER eligibility yet, so building
`META_ALLOCATOR_RL_V1` now would be premature engineering effort against strategies with no
evidence to allocate between.

## 18. Data

No live or historical data ingestion exists. All engine tests use hand-built or seeded-random
synthetic snapshots (`BookTop`, `PerpSnapshot`, `SpotSnapshot`, `Bar`). No Parquet/SQLite dataset
files have been created. This is the largest open gap: every "evidence: none" line above traces
back to this.

## 19. Execution

Not built. No exchange connector, no Nautilus integration, no order submission path exists
anywhere in `autotrade8/`. This is intentional and matches spec §109 (SHADOW → PAPER only).

## 20. Hedge Safety

`hedge.py`: explicit 10-state machine (PROPOSED→...→CLOSED/FAILED) with an illegal-transition
guard. `MultiLegBundle.evaluate()` is a pure fail-closed supervisor: unhedged-timeout → retry (up
to `max_hedge_retries`) → unwind → halt; leg slippage over `max_leg_slippage_bps` → immediate
unwind; unresolved emergency past 2× timeout → escalate. All limits are config placeholders
(`HedgeLimits` defaults), not calibrated to any real venue.

## 21. Risk

Risk categories are declared per-opportunity (`Opportunity.risks` dict: basis, funding, venue,
model, directional) but there is no aggregate portfolio-level risk model yet — each opportunity is
evaluated independently. Circuit breakers (§57) are not implemented; SENTRY's `RISK` gate only
checks a caller-supplied `halt_reason` string, it does not compute halt conditions itself.

## 22–24. Walk-Forward / CPCV / Holdout

`validation.py` implements all three as generic, reusable primitives (`chrono_split`,
`walk_forward_folds`, `cpcv_splits` + `cpcv_paths` + `summarize_paths`), verified for
no-lookahead and correct purge/embargo gaps by test. **Not yet wired into the funding or basis
scanners** — only the breakout backtester's `evaluate()` currently uses the chronological split.

## 25. Overfitting Audit

`signflip_null_pvalue` (bootstrap null against a zero-mean symmetric distribution, returns `None`
below 30 samples rather than a fake p-value) and `random_pick_null_pvalue` (strategy pick vs.
random pick from the same eligible sets) are implemented and tested to correctly distinguish
genuine edge from noise on synthetic data. Deflated Sharpe Ratio, Probability of Backtest
Overfitting, and White's Reality Check are **not implemented** — flagged as remaining work, not
silently skipped.

## 26. Ablation

Breakout has four wired variants (base / volume-zone / stochastic / full-context) sharing one
scan path, confirmed structurally distinct by test. On-chain has five nested ablation sets
(HOUND alone through full HOUND+ECHO+TIDE+RAIL+GUARD) computed automatically by
`onchain.shadow_record`. Neither has been run against real data to measure actual incremental
value — the harness exists, the evidence does not.

## 27. Tournament

`tournament.py::render` produces the fixed-column table from spec §90/§103. Verified by test to
print `INSUFFICIENT_EVIDENCE` for any strategy without a supplied `EligibilityMetrics`, and never
to backfill a plausible-looking number.

## 28. PAPER Eligibility

`lifecycle.py::paper_eligibility` checks the full floor from §79 (positive gross/net expectancy,
PF≥1.10 floor, positive validation/test/holdout/stress, drawdown and concentration ceilings,
parameter stability, execution-model credibility) and returns every unmet criterion, not just the
first. `to_eligibility()` defaults `execution_model_credible=False` — **no strategy can become
eligible from backtest results alone**, by design; it requires PAPER-stage expected-vs-realized
calibration that does not exist yet.

## 29. Dashboard

Not built.

## 30. Tests

111 tests across 10 test files (1,228 lines), all passing. `ruff check .` clean. `mypy
autotrade8 --strict` clean (tests are not type-checked under --strict, matching normal practice).
No Playwright run (no dashboard exists to test).

## 31. Failure Injection

Covered at the unit level within `hedge.py`'s test suite: one-leg-fill-only, leg slippage spike,
partial-fill timeout, unresolved emergency escalation. **Not covered:** stale venue mid-scan,
restart-while-hedged, corrupted checkpoint, duplicate events, cross-process timestamp mismatch —
none of these are meaningful without a running process and persistence layer, neither of which
exists yet.

## 32–33. Bugs Found / Fixed

1. **SENTRY EXPOSURE gate fail-open at zero exposure** (§10 above) — fixed to fail closed.
2. **Funding persistence threshold too permissive** — a noisy-but-net-positive funding history
   (persistence score 0.56) passed at the initial 0.5 threshold; raised to 0.7. Still a
   placeholder pending real calibration, not a final answer.
3. **RAIL test threshold mis-set** during test authoring (a notional value that produced DEGRADED
   instead of the intended REJECTED) — corrected the test input, not the implementation; caught
   because the test asserted a specific state rather than "not EXECUTABLE".
4. **Test-only random-walk seeds occasionally satisfied stationarity by chance** (~6% false rate,
   matching the DF test's own significance level) — addressed by testing the full gate stack's
   aggregate false-positive rate explicitly rather than asserting on a single arbitrary seed.

## 34. Remaining Blockers

- No real market data anywhere (highest priority — nothing below can be evidenced without it).
- No AUTOTRADE 7 repository was available to audit or integrate with in this session.
- No NautilusTrader integration.
- No dashboard, no Playwright verification.
- No portfolio-level risk aggregation or circuit breakers.
- Deflated Sharpe / PBO / White's Reality Check not implemented.
- Walk-forward/CPCV not yet wired into funding or basis scanners (only breakout).
- All numeric thresholds throughout (`SentryConfig`, `HedgeLimits`, `BasisConfig`,
  `BreakoutConfig`, `EligibilityFloor`, `min_persistence`) are unvalidated placeholders.

## 35. Changed Files

New package `autotrade8/`: `opportunity.py`, `costs.py`, `funding.py`, `sentry.py`,
`allocator.py`, `hedge.py`, `volume_zone.py`, `scanner.py`, `basis.py`, `breakout.py`,
`backtest.py`, `onchain.py`, `validation.py`, `lifecycle.py`, `tournament.py`. Tests:
`tests/test_econ.py`, `test_sentry.py`, `test_allocator.py`, `test_hedge.py`,
`test_volume_zone.py`, `test_scanner.py`, `test_basis.py`, `test_breakout.py`,
`test_backtest.py`, `test_onchain.py`, `test_validation.py`, `test_tournament.py`,
`tests/helpers.py`. This report.

## 36. Commits

None — no git repository was initialized in this sandbox; delivered as a standalone package
(`autotrade8_phase1.zip`) for the person to merge into their own AUTOTRADE 7 repo and commit
there.

## 37. Runtime State

Not applicable — nothing has been run outside `pytest`. No process, no live state, no PAPER
session exists.

## 38. Next Experiment

Wire a public-data collector (funding rates, BBO, mark/index for at least Gate plus one more
venue) into Parquet, freeze a `FUNDING_HISTORY_V1` dataset per spec §60, and re-run
`scan_funding_carry` / `scan_cross_exchange_funding` against it through `validation.py`'s
walk-forward + CPCV — the first point at which this system can produce a real (non-synthetic)
`INSUFFICIENT_EVIDENCE` or `CANDIDATE` verdict.

---

## AUTOTRADE 8.0 FINAL STATUS

```
Commit:               NONE (no git repo in this environment)
Mode:                 SHADOW (research only; no execution path exists)
Equity:               N/A (no account connected)
Qualified alpha families: 0
PAPER eligible:        0
PAPER active:          NONE
LIVE:                  DISABLED (no LIVE state exists in the lifecycle enum)

Funding Carry:              INSUFFICIENT_EVIDENCE (synthetic tests only)
Cross-Exchange Funding:     INSUFFICIENT_EVIDENCE (synthetic tests only)
Cross-Exchange Basis:       INSUFFICIENT_EVIDENCE (synthetic tests only)
Cross-Sectional Breakout:   INSUFFICIENT_EVIDENCE (random-walk test shows no false edge)
Volume Zone incremental value: INSUFFICIENT_EVIDENCE (ablation harness untested on real data)
Onchain Event:               SHADOW (structurally non-executable; no live data source)
RL Meta Allocator:            NOT_STARTED

BEST QUALIFIED CAPITAL USE:   CASH

CRITICAL BLOCKERS:
  1. No real market data source connected
  2. No AUTOTRADE 7 repository available to audit/integrate in this session
  3. No NautilusTrader / execution integration
  4. No dashboard
  5. All risk/eligibility thresholds are uncalibrated placeholders

REPORT: docs/AUTOTRADE_8_FINAL_IMPLEMENTATION_REPORT_2026-09-25.md
```
